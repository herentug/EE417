clc;clear all;close all;

% Hakan Bugra Erentug

% Task 1
% I = checkerboard;
% I=imread('blocks.png')
% imshow(I);
% I=rgb2gray(I);
% 
% imshow(lab4ktcorners(I,20))

% Task 2
% tic
% I2= imread('checker.jpg');
% lab4houghlines(I2);
% toc

% Task 3
I=imread("circlesBrightDark.png")

lab4houghcircles(I);


