% Hakna Buğra Ernetuğ
clear all;
close all;
clc;


I = imread('t.jpeg');
lab5calibpreb(I);

